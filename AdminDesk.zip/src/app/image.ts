export class Image {
    
    imageUrl: string;
    imageDesc: string;
    charges : Number;
}
//remember to import this class where required.