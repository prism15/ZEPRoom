export interface VacantModel {
    Name : String,
    Phone : Number,
    roomNumber : Number,
    documentName : String,
    documentNumber : String,
    startDate: Date,
    endDate : Date,
    Amount : Number,
    roomid : String,
    status : String
}