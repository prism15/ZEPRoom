import { NgModule  } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgxNumberSpinnerModule } from 'ngx-number-spinner';




@NgModule({
  declarations: [],
  imports: [
  
  CommonModule,
  NgxNumberSpinnerModule
  ]
})
export class BookroomModule { }
