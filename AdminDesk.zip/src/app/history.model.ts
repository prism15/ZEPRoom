export interface HistoryModel{
    Name : String,
    Phone : String,
    documentName : String,
    documentNumber : String,
    startDate: Date,
    endDate : Date,
    Amount : Number,
    roomNumber : Number,
    roomid : String,
    status : String
}