export interface RoomModel {
    imagePath : String,
    roomNumber : Number,
    Type : String,
    description : String,
    charges : Number

}